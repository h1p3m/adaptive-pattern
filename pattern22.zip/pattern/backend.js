//node js express server
const express = require('express');
const app = express();
const port = 3000;
//file system
const fs = require('fs');


//cors
const cors = require('cors');
app.use(cors());

//body parser
const bodyParser = require('body-parser');
app.use(bodyParser.json());


app.get('/', (req, res) => res.send('Hello World!'));


app.post("/saveMemories", (req, res) => {
    console.log("saveMemories");
    res.send("saveMemories");
});

app.post("/loadMemories", (req, res) => {
    console.log("loadMemories");
  //read tsv file

   fs.readFile('sociation.tsv', 'utf8', function(err, data) {
    if (err) throw err;
    console.log(data);

    //convert to json
    var lines = data.split("\n");
    var result = [];
    var headers = lines[0].split("\t");

    for(var i=1;i<lines.length;i++){

        var obj = {};
        var currentline = lines[i].split("\t");

        for(var j=0;j<headers.length;j++){
            obj[headers[j]] = currentline[j];
        }

        result.push(obj);

    }

res.send(result);
    //res.send(data);

   });


});



app.listen(port, () => console.log(`Example app listening on port ${port}!`));


